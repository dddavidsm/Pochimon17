package model;

public class TypedElement {

}
