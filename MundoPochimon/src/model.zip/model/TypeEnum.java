package model;

public enum TypeEnum {
    FIRE, WATER, PLANT, ELECTRIC, PSYCHIC, NORMAL, FIGHTING
}
