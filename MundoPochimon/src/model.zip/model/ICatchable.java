package model;

public interface ICatchable {
	   
	boolean tryToCatch();
    
	double getCaptureRate();
}
