package model;

public class Badge {

}
